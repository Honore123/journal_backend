Journal Backend
